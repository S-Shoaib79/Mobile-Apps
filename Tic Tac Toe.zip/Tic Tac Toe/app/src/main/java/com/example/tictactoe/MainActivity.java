package com.example.tictactoe;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    int turn = 0;
    int data[][];
    ImageButton buttons[][];
    TextView myTextView;
    Button c;
    boolean checkwin()
    {
        if(data[0][0]==data[1][0]&& data[1][0]==data[2][0]&&data[0][0]!=0)
        {
            return true;
        }
        else if(data[0][1]==data[1][1]&& data[1][1]==data[2][1]&&data[0][1]!=0)
        {
            return true;
        }
        else if(data[0][0]==data[0][1]&& data[0][1]==data[0][2]&&data[0][0]!=0)
        {
            return true;
        }
        else if(data[0][2]==data[1][2]&& data[1][2]==data[2][2]&&data[0][2]!=0)
        {
            return true;
        }
        else if(data[1][0]==data[1][1]&& data[1][1]==data[1][2]&&data[1][0]!=0)
        {
            return true;
        }
        else if(data[2][0]==data[2][1]&& data[2][1]==data[2][2]&&data[2][0]!=0)
        {
            return true;
        }
        else if(data[0][0]==data[1][1]&& data[1][1]==data[2][2]&&data[0][0]!=0)
        {
            return true;
        }
        else if(data[0][2]==data[1][1]&& data[1][1]==data[2][0]&&data[0][2]!=0)
        {
            return true;
        }
        else {
            return false;
        }
    }
    void resetf()
    {
        for(int i=0; i<3; i++)
        {
            for(int j=0; j<3; j++)
            {
                data[i][j]=0;
                buttons[i][j].setImageResource(R.drawable.blank);
            }
        }
        turn=0;
        myTextView.setText("Player 1 Turn");

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        data = new int[3][3];
        buttons = new ImageButton[3][3];
        myTextView=findViewById(R.id.text);
        c= findViewById(R.id.reset);
        buttons[0][0] = findViewById(R.id.b1);
        buttons[0][1] = findViewById(R.id.b2);
        buttons[0][2] = findViewById(R.id.b3);
        buttons[1][0] = findViewById(R.id.b4);
        buttons[1][1] = findViewById(R.id.b5);
        buttons[1][2] = findViewById(R.id.b6);
        buttons[2][0] = findViewById(R.id.b7);
        buttons[2][1] = findViewById(R.id.b8);
        buttons[2][2] = findViewById(R.id.b9);



        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
//                int finalI = i;
//                int finalJ = j;

                buttons[i][j].setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        for (int a = 0; a < 3; a++) {
                            for (int b = 0; b < 3; b++) {
                                if (view == buttons[a][b]) {
                                    Log.d("*****", "Pressed: " + a + "," + b);

                                    if (data[a][b] == 0) {
                                        if (turn % 2 == 0 ) {
                                            myTextView.setText("Player 2 turn");
                                            buttons[a][b].setImageResource(R.drawable.circle);
                                            data[a][b] = 1;
                                        } else {
                                            if(turn!=9) {
                                                myTextView.setText("Player 1 turn");
                                            }
                                            buttons[a][b].setImageResource(R.drawable.cross);
                                            data[a][b] = 2;
                                        }
                                        turn++;
                                        Log.d("*****", "Turn value: " + turn);
                                        if(checkwin())
                                        {
                                            if(turn%2==0) {
                                                myTextView.setText("PLAYER 2 WINS");
                                            }
                                            else {
                                                myTextView.setText("PLAYER 1 WINS");
                                            }

                                        }
                                        else if( turn==9 && !checkwin())
                                        {
                                            myTextView.setText("IT'S A TIE");
                                        }

                                    }

                                    else {
                                        Log.d("*****", "Already occupies: " + a + "," + b);
                                    }
                                }
                            }
                        }
                    }
                });
c.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
    resetf();
    }
});
            }
        }
    }
}
