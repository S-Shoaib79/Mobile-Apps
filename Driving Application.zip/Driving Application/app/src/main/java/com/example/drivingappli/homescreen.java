package com.example.drivingappli;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;

import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class homescreen extends AppCompatActivity implements SensorEventListener, LocationListener {

    private static final String INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-3940256099942544/1033173712";
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1;

    private TextView currInfoTxt, currTripTxt;
    private Button startButton, stopButton, tripsButton;
    private int currentTripNumber = 0;
    private ArrayList<String> currentTripViolations = new ArrayList<>();
    private boolean isTripActive = false;

    private SensorManager sensorManager;
    private Sensor accelerometer;
    private LocationManager locationManager;
    private static final float SPEED_LIMIT = 80.0f;

    private AdView bannerAdView;
    private InterstitialAd interstitialAd;

    private Location lastKnownLocation = null;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.homescreenn);

        currInfoTxt = findViewById(R.id.currinfotxt);
        currTripTxt = findViewById(R.id.currtriptxt);
        startButton = findViewById(R.id.startbtn);
        stopButton = findViewById(R.id.stopbtn);
        tripsButton = findViewById(R.id.tripsbtn);

        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        bannerAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        bannerAdView.loadAd(adRequest);

        loadInterstitialAd();

        startButton.setOnClickListener(view -> startNewTrip());
        stopButton.setOnClickListener(view -> stopTrip());
        tripsButton.setOnClickListener(view -> {
            showInterstitialAd();
            Intent intent = new Intent(this, TripsActivity.class);
            startActivity(intent);
        });

        updateCurrentTripNumber(currentTripNumber);
        updateCurrentTripDetails();
    }

    private void startNewTrip() {
        if (!isTripActive) {
            currentTripNumber++;
            isTripActive = true;
            currentTripViolations.clear();
            addViolation("Trip started: " + getCurrentTime(), null);
            updateCurrentTripNumber(currentTripNumber);
            updateCurrentTripDetails();

            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);

            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                    && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
                return;
            }
            // Request location updates from both providers
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 1, this);
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1000, 1, this);
        }
    }

    private void stopTrip() {
        if (isTripActive) {
            isTripActive = false;
            addViolation("Trip ended: " + getCurrentTime(), null);
            saveTripData();
            updateCurrentTripDetails();
            sensorManager.unregisterListener(this);
            locationManager.removeUpdates(this);
        }
    }

    private void addViolation(String violation, Location location) {
        StringBuilder violationEntry = new StringBuilder(getCurrentTime() + " - " + violation);
        if (location != null) {
            violationEntry.append(" (Lat: ").append(location.getLatitude())
                    .append(", Long: ").append(location.getLongitude()).append(")");
        }
        currentTripViolations.add(violationEntry.toString());
        updateCurrentTripDetails();
    }

    private void updateCurrentTripDetails() {
        StringBuilder details = new StringBuilder();
        for (String violation : currentTripViolations) {
            details.append(violation).append("\n");
        }
        currInfoTxt.setText(details.toString());
    }

    private void updateCurrentTripNumber(int tripNumber) {
        currTripTxt.setText("Trip #" + tripNumber);
    }

    private void saveTripData() {
        String fileName = "trips.txt";
        StringBuilder data = new StringBuilder("Trip #" + currentTripNumber + " - " + getCurrentDate() + "\n");

        for (String violation : currentTripViolations) {
            data.append(violation).append("\n");
        }

        try (FileOutputStream fos = openFileOutput(fileName, Context.MODE_APPEND)) {
            fos.write(data.toString().getBytes());
            Toast.makeText(this, "Trip data saved", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String getCurrentDate() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
    }

    private String getCurrentTime() {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (isTripActive && event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            float x = event.values[0];
            float y = event.values[1];
            float z = event.values[2];
            float acceleration = (float) Math.sqrt(x * x + y * y + z * z);

            if (acceleration > 15) {
                addViolation("Harsh Braking Detected", lastKnownLocation);
            } else if (acceleration > 12) {
                addViolation("Strong Acceleration Detected", lastKnownLocation);
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {}

    @Override
    public void onLocationChanged(@NonNull Location location) {
        if (isTripActive) {
            lastKnownLocation = location; // Update the latest location
            float speed = location.getSpeed() * 3.6f;
            if (speed > SPEED_LIMIT) {
                addViolation("Over-speeding Detected at " + speed + " km/h", location);
            }
        }
    }

    @Override
    public void onProviderEnabled(@NonNull String provider) {
        // React when location provider is enabled
    }

    @Override
    public void onProviderDisabled(@NonNull String provider) {
        // React when location provider is disabled
    }

    private void loadInterstitialAd() {
        AdRequest adRequest = new AdRequest.Builder().build();
        InterstitialAd.load(this, INTERSTITIAL_AD_UNIT_ID, adRequest, new InterstitialAdLoadCallback() {
            @Override
            public void onAdLoaded(@NonNull InterstitialAd ad) {
                interstitialAd = ad;
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                interstitialAd = null;
            }
        });
    }

    private void showInterstitialAd() {
        if (interstitialAd != null) {
            interstitialAd.show(this);
            loadInterstitialAd();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startNewTrip(); // Retry starting trip if permission is now granted
            } else {
                Toast.makeText(this, "Location permission is required to track trips.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
