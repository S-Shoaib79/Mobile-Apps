package com.example.drivingappli;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class TripsActivity extends AppCompatActivity {

    private ArrayList<String> tripList;
    private InterstitialAd interstitialAd;
    private AdView bannerAdView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tripactivity);

        // Initialize the banner ad
        bannerAdView = findViewById(R.id.adView2);
        AdRequest adRequest = new AdRequest.Builder().build();
        bannerAdView.loadAd(adRequest);

        // Load the interstitial ad
        loadInterstitialAd();

        // Load trip data from the text file
        tripList = loadTripsFromFile();

        // Check if tripList is not null and not empty before looping
        if (tripList != null && !tripList.isEmpty()) {
            LinearLayout tripContainer = findViewById(R.id.tripContainer);
            for (int i = 0; i < tripList.size(); i++) {
                String tripInfo = tripList.get(i);

                // Split tripInfo by a delimiter if needed, e.g., " - " to separate the name and date
                String[] parts = tripInfo.split(" - ", 2);
                String tripName = parts.length > 0 ? parts[0] : "Trip #" + (i + 1);
                String tripDate = parts.length > 1 ? parts[1].split("\n")[0] : "No Date"; // Extract only the date

                // Create a TextView to display only the trip name and date
                TextView tripTextView = new TextView(this);
                tripTextView.setText(tripName + "\nDate: " + tripDate);
                tripTextView.setPadding(16, 16, 16, 16);
                tripTextView.setTextSize(18);
                tripTextView.setTextColor(getResources().getColor(android.R.color.white));
                tripTextView.setId(i);
                tripTextView.setClickable(true);

                // Set a click listener to open the trip details
                tripTextView.setOnClickListener(view -> openTripDetail(tripInfo));

                // Add the TextView to the container
                tripContainer.addView(tripTextView);
            }
        }

        // Set up the back button to go back to the home screen
        Button backButton = findViewById(R.id.button);
        backButton.setOnClickListener(v -> {
            showInterstitialAd();
            Intent intent = new Intent(TripsActivity.this, homescreen.class);
            startActivity(intent);
            finish();
        });
    }

    // Method to read trips from the text file (trips.txt in internal storage)
    private ArrayList<String> loadTripsFromFile() {
        ArrayList<String> trips = new ArrayList<>();
        try {
            FileInputStream fis = openFileInput("trips.txt");
            BufferedReader reader = new BufferedReader(new InputStreamReader(fis));
            String line;
            StringBuilder tripData = new StringBuilder();

            while ((line = reader.readLine()) != null) {
                if (line.startsWith("Trip #")) { // Each trip starts with "Trip #"
                    if (tripData.length() > 0) {
                        trips.add(tripData.toString()); // Save previous trip data
                        tripData = new StringBuilder();
                    }
                }
                tripData.append(line).append("\n");
            }
            if (tripData.length() > 0) {
                trips.add(tripData.toString()); // Add the last trip
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return trips;
    }

    private void openTripDetail(String tripInfo) {
        showInterstitialAd(); // Show interstitial ad before opening detail screen
        Intent intent = new Intent(this, TripsActivityDetail.class);
        intent.putExtra("tripInfo", tripInfo);
        startActivity(intent);
    }



    // Method to load interstitial ad
    private void loadInterstitialAd() {
        // Dynamically create TextViews for each trip

        AdRequest adRequest = new AdRequest.Builder().build();
        InterstitialAd.load(this, "ca-app-pub-3940256099942544/1033173712", adRequest, new InterstitialAdLoadCallback() {
            @Override
            public void onAdLoaded(InterstitialAd ad) {
                interstitialAd = ad;
                interstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                    @Override
                    public void onAdDismissedFullScreenContent() {
                        interstitialAd = null; // Clear the ad and load a new one
                        loadInterstitialAd(); // Pre-load the next interstitial ad
                    }

                    @Override
                    public void onAdFailedToShowFullScreenContent(com.google.android.gms.ads.AdError adError) {
                        interstitialAd = null; // Clear the ad if it fails to show
                    }
                });
            }

            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
                // Handle ad loading error
                interstitialAd = null;
            }
        });
    }

    // Method to show the interstitial ad
    private void showInterstitialAd() {
        if (interstitialAd != null) {
            interstitialAd.show(this);
        } else {
            loadInterstitialAd(); // If the ad isn't ready, load another
        }
    }
}