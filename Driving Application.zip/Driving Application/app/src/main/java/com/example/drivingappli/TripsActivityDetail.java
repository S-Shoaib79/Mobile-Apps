package com.example.drivingappli;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TripsActivityDetail extends AppCompatActivity {

    private String locationCoordinates;
    private AdView bannerAdView;
    private InterstitialAd interstitialAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tripsactivitydetail);

        // Set up the banner ad
        bannerAdView = findViewById(R.id.bannerAdView);
        AdRequest adRequest = new AdRequest.Builder().build();
        bannerAdView.loadAd(adRequest);

        // Load interstitial ad
        loadInterstitialAd();

        TextView tripDetailsTextView = findViewById(R.id.tripDetailsTextView);
        ImageButton openMapButton = findViewById(R.id.openMapButton);
        Button showInterstitialButton = findViewById(R.id.showInterstitialButton);

        // Retrieve trip info from the intent
        String tripInfo = getIntent().getStringExtra("tripInfo");
        tripDetailsTextView.setText(tripInfo);

        // Extract location coordinates from trip info
        locationCoordinates = extractLocationCoordinates(tripInfo);
        Log.d("Debug", "Extracted Coordinates: " + locationCoordinates); // Debugging

        // Set up the image button to open Google Maps
        openMapButton.setOnClickListener(v -> {
            if (locationCoordinates != null) {
                openGoogleMaps(locationCoordinates);
            } else {
                Toast.makeText(this, "No location available for this trip.", Toast.LENGTH_SHORT).show();
            }
        });

        // Set up the button to display the interstitial ad
        showInterstitialButton.setOnClickListener(v -> {
            showInterstitialAd();
            Intent intent = new Intent(TripsActivityDetail.this, TripsActivity.class);
            startActivity(intent);
            finish();
        });

    }

    private void loadInterstitialAd() {
        AdRequest adRequest = new AdRequest.Builder().build();
        InterstitialAd.load(this, "ca-app-pub-3940256099942544/1033173712", adRequest, new InterstitialAdLoadCallback() {
            @Override
            public void onAdLoaded(InterstitialAd ad) {
                interstitialAd = ad;
                interstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                    @Override
                    public void onAdDismissedFullScreenContent() {
                        interstitialAd = null; // Clear the ad and load a new one
                        loadInterstitialAd(); // Pre-load the next interstitial ad
                    }

                    @Override
                    public void onAdFailedToShowFullScreenContent(com.google.android.gms.ads.AdError adError) {
                        interstitialAd = null; // Clear the ad if it fails to show
                    }
                });
            }

            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
                // Handle ad loading error
                interstitialAd = null;
            }
        });
    }

    // Method to show the interstitial ad
    private void showInterstitialAd() {
        if (interstitialAd != null) {
            interstitialAd.show(this);
        } else {
            loadInterstitialAd(); // If the ad isn't ready, load another
        }
    }

    private String extractLocationCoordinates(String tripInfo) {
        String coordinatesPattern = "Lat:([-\\d.]+), Long:([-\\d.]+)";
        Pattern pattern = Pattern.compile(coordinatesPattern);
        Matcher matcher = pattern.matcher(tripInfo);
        if (matcher.find()) {
            return matcher.group(1) + "," + matcher.group(2); // Return as "latitude,longitude"
        }
        return null;
    }

    private void openGoogleMaps(String coordinates) {
        // Simplified URI format for Google Maps
        Uri mapUri = Uri.parse("geo:" + coordinates);
        Intent mapIntent = new Intent(Intent.ACTION_VIEW, mapUri);
        mapIntent.setPackage("com.google.android.apps.maps");

        if (mapIntent.resolveActivity(getPackageManager()) != null) {
            startActivity(mapIntent);
        } else {
            Toast.makeText(this, "Google Maps is not installed.", Toast.LENGTH_SHORT).show();
        }
    }
}
