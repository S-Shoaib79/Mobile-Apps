package com.example.weatherforecast;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;

public class MainActivity extends AppCompatActivity {


private ImageButton wimg;
private ProgressBar progressBar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        progressBar = findViewById(R.id.progressBar);
        Button b = findViewById(R.id.btnenter);
        EditText cityname = findViewById(R.id.cityname);
        TextView result = findViewById(R.id.result);
        TextView temptxt = findViewById(R.id.temptxt);
        TextView feeltxt = findViewById(R.id.feeltxt);
        TextView mintxt = findViewById(R.id.mintxt);
        TextView maxtxt = findViewById(R.id.maxtxt);
        TextView humtxt = findViewById(R.id.humtxt);
        TextView windspeedtxt = findViewById(R.id.windspeedtxt);
        TextView winddirtxt = findViewById(R.id.winddirtxt);
        wimg = findViewById(R.id.wimg);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                progressBar.setVisibility(View.VISIBLE);
                Thread t = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            String city = cityname.getText().toString();
                            URL url = new URL("https://api.openweathermap.org/data/2.5/weather\n" + "?q="+city+",pk&appid=b62d2933578addcbbbbd3c6afe7df606");

                            BufferedReader br = new BufferedReader(new InputStreamReader(url.openStream()));
                            char[] buffer = new char[100000];
                            int count = br.read(buffer);
                            String jsonResponse = new String(buffer, 0, count);


                            JSONObject jsonObject = new JSONObject(jsonResponse);
                            JSONObject main = jsonObject.getJSONObject("main");
                            JSONArray weatherArray = jsonObject.getJSONArray("weather");
                            JSONObject weather = weatherArray.getJSONObject(0);

                            String weatherDescription = weather.getString("description");
                            String weatherIcon = weather.getString("icon");
                            double temp = main.getDouble("temp")-273.15;

                            double feelsLike = main.getDouble("feels_like")-273.15;

                            double tempMin = main.getDouble("temp_min")-273.15;

                            double tempMax = main.getDouble("temp_max")-273.15;

                            int humidity = main.getInt("humidity");
                            double windSpeed = jsonObject.getJSONObject("wind").getDouble("speed");
                            double windDirection= jsonObject.getJSONObject("wind").getDouble("deg");

                            runOnUiThread(() -> {
                                result.setText(weatherDescription);
                                temptxt.setText("Temp: " + temp + "°C");
                                feeltxt.setText("Feels Like: " + feelsLike + "°C");
                                mintxt.setText("Min Temp: " + tempMin + "°C");
                                maxtxt.setText("Max Temp: " + tempMax + "°C");
                                humtxt.setText("Humidity: " + humidity + "%");
                                windspeedtxt.setText("Wind Speed: " + windSpeed + " m/s");
                                winddirtxt.setText("Wind Direction: "+windDirection);

                                setWeatherIcon(weatherIcon);
                                progressBar.setVisibility(View.GONE);
                            });

                        } catch (Exception e) {
                            runOnUiThread(() -> Toast.makeText(MainActivity.this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show());
                        }
                    }
                });
                t.start();
            }
        });
    }


    private void setWeatherIcon(String weatherIcon) {
        switch (weatherIcon) {
            case "01d":
                wimg.setImageResource(R.drawable.sunnyday);
                break;
            case "01n":
                wimg.setImageResource(R.drawable.night);
                break;
            case "02d":
                wimg.setImageResource(R.drawable.cloudyday);
                break;
            case "02n":
                wimg.setImageResource(R.drawable.cloudynight);
                break;
            case "03d":
                wimg.setImageResource(R.drawable.cloudy);
                break;
            case "03n":
                wimg.setImageResource(R.drawable.cloudy);
                break;

            case "04d":
                wimg.setImageResource(R.drawable.blackcloudy);
                break;
            case "04n":
                wimg.setImageResource(R.drawable.blackcloudy);
                break;
            case "09d":
                wimg.setImageResource(R.drawable.raincloudblack);
                break;
            case "09n":
                wimg.setImageResource(R.drawable.raincloudblack);
                break;
            case "10d":
                wimg.setImageResource(R.drawable.rainday);
                break;
            case "10n":
                wimg.setImageResource(R.drawable.rainnight);
                break;
            case "11d":
                wimg.setImageResource(R.drawable.thunder);
                break;
            case "11n":
                wimg.setImageResource(R.drawable.thunder);
                break;

            case "13n":
                wimg.setImageResource(R.drawable.frost);
                break;
            case "50d":
                wimg.setImageResource(R.drawable.smoke);
                break;
            case "50n":
                wimg.setImageResource(R.drawable.smoke);
                break;
            default:
                wimg.setImageResource(R.drawable.pic);
                break;
        }
    }
}
